<?php
  include 'header.php';
?>

  <!-- ======= Message Content ======= -->
  <section class="main-content message-page">
    <div class="container-fluid">
      <div class="row">
        <div class="message-page-inside">
          <div class="col-sm-4 sidebar-message p-0">
            <h1>الرسائل</h1>
            <ul class="nav nav-tabs">
              <li class="active">
                <a data-toggle="tab" href="#m-1">
                  <img src="assets/images/userprofile.png" class="" alt="" />
                  <strong>خالد محمد</strong>
                  <p>هناك حقيقة مثبتة منذ زمن طويل</p>
                </a>
              </li>
              <li class="">
                <a data-toggle="tab" href="#m-2">
                  <img src="assets/images/userprofile.png" class="" alt="" />
                  <strong>خالد محمد</strong>
                  <p>هناك حقيقة مثبتة منذ زمن طويل</p>
                </a>
              </li>
              <li class="">
                <a data-toggle="tab" href="#m-3">
                  <img src="assets/images/userprofile.png" class="" alt="" />
                  <strong>خالد محمد</strong>
                  <p>هناك حقيقة مثبتة منذ زمن طويل</p>
                </a>
              </li>
              <li class="">
                <a data-toggle="tab" href="#m-4">
                  <img src="assets/images/userprofile.png" class="" alt="" />
                  <strong>خالد محمد</strong>
                  <p>هناك حقيقة مثبتة منذ زمن طويل</p>
                </a>
              </li>
              <li class="">
                <a data-toggle="tab" href="#m-5">
                  <img src="assets/images/userprofile.png" class="" alt="" />
                  <strong>خالد محمد</strong>
                  <p>هناك حقيقة مثبتة منذ زمن طويل</p>
                </a>
              </li>
              <li class="">
                <a data-toggle="tab" href="#m-6">
                  <img src="assets/images/userprofile.png" class="" alt="" />
                  <strong>خالد محمد</strong>
                  <p>هناك حقيقة مثبتة منذ زمن طويل</p>
                </a>
              </li>
            </ul>
          </div>
          <div class="col-sm-8 message p-0">
            <div class="tab-content">
              <div id="m-1" class="single-message tab-pane fade in active relative">
                <div class="chat-with-name">
                  <h3>فلان الفلاني</h3>
                </div>
                <!-- Main Date -->
                <div class="chat-with-date text-center">
                  <p>- قبل شهريين -</p>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Main Date -->
                <div class="chat-with-date text-center">
                  <p>- اليوم -</p>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <form>
                  <textarea class="form-control" rows="3" placeholder="اكتب رسالتك"></textarea>
                  <button class="btn" name="button"><i class="icon fa fa-location-arrow"></i></button>
                </form>
              </div>
              <div id="m-2" class="single-message tab-pane fade relative">
                <div class="chat-with-name">
                  <h3>فلان الفلاني</h3>
                </div>
                <!-- Main Date -->
                <div class="chat-with-date text-center">
                  <p>- قبل شهريين -</p>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Main Date -->
                <div class="chat-with-date text-center">
                  <p>- اليوم -</p>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <form>
                  <textarea class="form-control" rows="2" placeholder="اكتب رسالتك"></textarea>
                  <button class="btn" name="button"><i class="icon fa fa-location-arrow"></i></button>
                </form>
              </div>
              <div id="m-3" class="single-message tab-pane fade relative">
                <div class="chat-with-name">
                  <h3>فلان الفلاني</h3>
                </div>
                <!-- Main Date -->
                <div class="chat-with-date text-center">
                  <p>- قبل شهريين -</p>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Main Date -->
                <div class="chat-with-date text-center">
                  <p>- اليوم -</p>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <form>
                  <textarea class="form-control" rows="2" placeholder="اكتب رسالتك"></textarea>
                  <button class="btn" name="button"><i class="icon fa fa-location-arrow"></i></button>
                </form>
              </div>
              <div id="m-4" class="single-message tab-pane fade relative">
                <div class="chat-with-name">
                  <h3>فلان الفلاني</h3>
                </div>
                <!-- Main Date -->
                <div class="chat-with-date text-center">
                  <p>- قبل شهريين -</p>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Main Date -->
                <div class="chat-with-date text-center">
                  <p>- اليوم -</p>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <form>
                  <textarea class="form-control" rows="2" placeholder="اكتب رسالتك"></textarea>
                  <button class="btn" name="button"><i class="icon fa fa-location-arrow"></i></button>
                </form>
              </div>
              <div id="m-5" class="single-message tab-pane fade relative">
                <div class="chat-with-name">
                  <h3>فلان الفلاني</h3>
                </div>
                <!-- Main Date -->
                <div class="chat-with-date text-center">
                  <p>- قبل شهريين -</p>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Main Date -->
                <div class="chat-with-date text-center">
                  <p>- اليوم -</p>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <form>
                  <textarea class="form-control" rows="2" placeholder="اكتب رسالتك"></textarea>
                  <button class="btn" name="button"><i class="icon fa fa-location-arrow"></i></button>
                </form>
              </div>
              <div id="m-6" class="single-message tab-pane fade relative">
                <div class="chat-with-name">
                  <h3>فلان الفلاني</h3>
                </div>
                <!-- Main Date -->
                <div class="chat-with-date text-center">
                  <p>- قبل شهريين -</p>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Main Date -->
                <div class="chat-with-date text-center">
                  <p>- اليوم -</p>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <!-- Single Message -->
                <div class="media chat-with-message">
                  <div class="media-right">
                    <img src="assets/images/userprofile.png" class="media-object" >
                  </div>
                  <div class="media-body relative">
                    <h4 class="media-heading">فلان الفلاني</h4>
                    <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ</p>
                    <span class="chat-with-message-date">١٠:٣٠ مساء</span>
                  </div>
                </div>
                <form>
                  <textarea class="form-control" rows="2" placeholder="اكتب رسالتك"></textarea>
                  <button class="btn" name="button"><i class="icon fa fa-location-arrow"></i></button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<?php
  include 'footer.php';
?>
